To build the Abstractanator application and run it, ensure that your computer has the most recent version of Java's compiler.

From the command line, navigate within this directory's parent directory to \team01\Build\src\main\java\application\. Once there, run the following commands to build the application and then run it:

javac Main.java

java Main